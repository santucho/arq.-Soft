/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.udea.entity;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Administrador
 */
@Entity
@Table(name = "ventas")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Ventas.findAll", query = "SELECT v FROM Ventas v")
    , @NamedQuery(name = "Ventas.findByNumeroFactura", query = "SELECT v FROM Ventas v WHERE v.numeroFactura = :numeroFactura")
    , @NamedQuery(name = "Ventas.findByFechaVenta", query = "SELECT v FROM Ventas v WHERE v.fechaVenta = :fechaVenta")
    , @NamedQuery(name = "Ventas.findByMatriculaVehiculo", query = "SELECT v FROM Ventas v WHERE v.matriculaVehiculo = :matriculaVehiculo")
    , @NamedQuery(name = "Ventas.findByFotoVehiculo", query = "SELECT v FROM Ventas v WHERE v.fotoVehiculo = :fotoVehiculo")
    , @NamedQuery(name = "Ventas.findByPrecioVehiculo", query = "SELECT v FROM Ventas v WHERE v.precioVehiculo = :precioVehiculo")
    , @NamedQuery(name = "Ventas.findByModeloVehiculo", query = "SELECT v FROM Ventas v WHERE v.modeloVehiculo = :modeloVehiculo")
    , @NamedQuery(name = "Ventas.findByReferenciaVehiculo", query = "SELECT v FROM Ventas v WHERE v.referenciaVehiculo = :referenciaVehiculo")
    , @NamedQuery(name = "Ventas.findByMarcaVehiculo", query = "SELECT v FROM Ventas v WHERE v.marcaVehiculo = :marcaVehiculo")
    , @NamedQuery(name = "Ventas.findByIDCliente", query = "SELECT v FROM Ventas v WHERE v.iDCliente = :iDCliente")
    , @NamedQuery(name = "Ventas.findByNombreCliente", query = "SELECT v FROM Ventas v WHERE v.nombreCliente = :nombreCliente")
    , @NamedQuery(name = "Ventas.findByEmailCliente", query = "SELECT v FROM Ventas v WHERE v.emailCliente = :emailCliente")})
public class Ventas implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "NumeroFactura")
    private Integer numeroFactura;
    @Basic(optional = false)
    @NotNull
    @Column(name = "FechaVenta")
    @Temporal(TemporalType.TIMESTAMP)
    private Date fechaVenta;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 6)
    @Column(name = "MatriculaVehiculo")
    private String matriculaVehiculo;
    @Size(max = 255)
    @Column(name = "FotoVehiculo")
    private String fotoVehiculo;
    @Basic(optional = false)
    @NotNull
    @Column(name = "PrecioVehiculo")
    private int precioVehiculo;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 50)
    @Column(name = "ModeloVehiculo")
    private String modeloVehiculo;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 50)
    @Column(name = "ReferenciaVehiculo")
    private String referenciaVehiculo;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 50)
    @Column(name = "MarcaVehiculo")
    private String marcaVehiculo;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 50)
    @Column(name = "IDCliente")
    private String iDCliente;
    @Size(max = 50)
    @Column(name = "NombreCliente")
    private String nombreCliente;
    @Size(max = 50)
    @Column(name = "EmailCliente")
    private String emailCliente;

    public Ventas() {
    }

    public Ventas(Integer numeroFactura) {
        this.numeroFactura = numeroFactura;
    }

    public Ventas(Integer numeroFactura, Date fechaVenta, String matriculaVehiculo, int precioVehiculo, String modeloVehiculo, String referenciaVehiculo, String marcaVehiculo, String iDCliente) {
        this.numeroFactura = numeroFactura;
        this.fechaVenta = fechaVenta;
        this.matriculaVehiculo = matriculaVehiculo;
        this.precioVehiculo = precioVehiculo;
        this.modeloVehiculo = modeloVehiculo;
        this.referenciaVehiculo = referenciaVehiculo;
        this.marcaVehiculo = marcaVehiculo;
        this.iDCliente = iDCliente;
    }

    public Integer getNumeroFactura() {
        return numeroFactura;
    }

    public void setNumeroFactura(Integer numeroFactura) {
        this.numeroFactura = numeroFactura;
    }

    public Date getFechaVenta() {
        return fechaVenta;
    }

    public void setFechaVenta(Date fechaVenta) {
        this.fechaVenta = fechaVenta;
    }

    public String getMatriculaVehiculo() {
        return matriculaVehiculo;
    }

    public void setMatriculaVehiculo(String matriculaVehiculo) {
        this.matriculaVehiculo = matriculaVehiculo;
    }

    public String getFotoVehiculo() {
        return fotoVehiculo;
    }

    public void setFotoVehiculo(String fotoVehiculo) {
        this.fotoVehiculo = fotoVehiculo;
    }

    public int getPrecioVehiculo() {
        return precioVehiculo;
    }

    public void setPrecioVehiculo(int precioVehiculo) {
        this.precioVehiculo = precioVehiculo;
    }

    public String getModeloVehiculo() {
        return modeloVehiculo;
    }

    public void setModeloVehiculo(String modeloVehiculo) {
        this.modeloVehiculo = modeloVehiculo;
    }

    public String getReferenciaVehiculo() {
        return referenciaVehiculo;
    }

    public void setReferenciaVehiculo(String referenciaVehiculo) {
        this.referenciaVehiculo = referenciaVehiculo;
    }

    public String getMarcaVehiculo() {
        return marcaVehiculo;
    }

    public void setMarcaVehiculo(String marcaVehiculo) {
        this.marcaVehiculo = marcaVehiculo;
    }

    public String getIDCliente() {
        return iDCliente;
    }

    public void setIDCliente(String iDCliente) {
        this.iDCliente = iDCliente;
    }

    public String getNombreCliente() {
        return nombreCliente;
    }

    public void setNombreCliente(String nombreCliente) {
        this.nombreCliente = nombreCliente;
    }

    public String getEmailCliente() {
        return emailCliente;
    }

    public void setEmailCliente(String emailCliente) {
        this.emailCliente = emailCliente;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (numeroFactura != null ? numeroFactura.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Ventas)) {
            return false;
        }
        Ventas other = (Ventas) object;
        if ((this.numeroFactura == null && other.numeroFactura != null) || (this.numeroFactura != null && !this.numeroFactura.equals(other.numeroFactura))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.udea.entity.Ventas[ numeroFactura=" + numeroFactura + " ]";
    }
    
}
