/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.udea.servlet;

import com.udea.ejb.ClientesFacadeLocal;
import com.udea.ejb.VehiculosFacadeLocal;
import com.udea.ejb.VentasFacadeLocal;
import com.udea.entity.Clientes;
import com.udea.entity.Vehiculos;
import com.udea.entity.Ventas;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Administrador
 */
public class ConcesionarioServlet extends HttpServlet {

    @EJB
    private VehiculosFacadeLocal vehiculosFacade;
    @EJB
    private VentasFacadeLocal ventasFacade;
    @EJB
    private ClientesFacadeLocal clientesFacade; 
    
    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        try {
            String action=request.getParameter("action");
            String url= "index.jsp";      
            if(null != action) switch (action) {
                case "list":
                    List<Clientes> findAll = clientesFacade.findAll();
                    request.getSession().setAttribute("clientes", findAll);
                    url = "listAccounts.jsp";
                    break;
                case "login":
                    String u = request.getParameter("email");
                    String p = request.getParameter("contrasena");
                    boolean checklogin = clientesFacade.checkLogin(u,p);
                    if(checklogin) {                  
                        request.getSession().setAttribute("login", u);
                        //url = "manager.jsp";                        
                        url = "listas.jsp";                        
                        //
                    } else {
                        url = "login.jsp?error=1";
                    }   break;
                case "insert":{
                    Clientes a = new Clientes();
                    a.setContraseña(request.getParameter("contrasena"));
                    a.setEmail(request.getParameter("email"));
                    a.setId(request.getParameter("id"));
                    a.setNombre(request.getParameter("nombre"));
                    clientesFacade.create(a);
                    //url = "login.jsp";
                    url = "index_1.jsp";
                        break;
                    }        
                
                case "insertVehicle":{
                    Vehiculos a= new Vehiculos();
                    a.setMatricula(request.getParameter("matricula"));
                    a.setFoto(request.getParameter("foto"));
                    a.setPrecio(Integer.valueOf(request.getParameter("precio")));
                    a.setModelo(request.getParameter("modelo"));
                    a.setReferencia(request.getParameter("referencia"));
                    a.setMarca(request.getParameter("marca"));
                    vehiculosFacade.create(a);
                    url="listVehiculos.jsp";
                    break;
                }     

                case "delete":{
                    String id = request.getParameter("numeroUsuario");
                    Clientes a = clientesFacade.find(id);//Integer.valueOf(id)
                    clientesFacade.remove(a);
                    url = "ConcesionarioServlet?action=list";
                        break;
                    }
                case "logout":
                    request.getSession().removeAttribute("login");
                    url= "login.jsp";
                    break;
                    
                case "listVentas":
                    List<Ventas> findAllVentas = ventasFacade.findAll();
                    request.getSession().setAttribute("ventas", findAllVentas);
                    url = "listVentas.jsp";
                    break;
                    
                case "listVehiculos":
                    List<Vehiculos> findAllVehiculos = vehiculosFacade.findAll();
                    request.getSession().setAttribute("vehiculos", findAllVehiculos);
                    url = "listVehiculos.jsp";
                    break;
                    
                
                case "comprar":{
                    Ventas b = new Ventas();  
                    String attribute = (String) request.getSession().getAttribute("login");
                    Clientes c = clientesFacade.find(attribute);                   
                    String placa = request.getParameter("matricula"); //onseguir la info del carro
                    Vehiculos v = vehiculosFacade.find(placa);
                    b.setMatriculaVehiculo(v.getMatricula());
                    b.setFotoVehiculo(v.getFoto());
                    b.setPrecioVehiculo(v.getPrecio());
                    b.setModeloVehiculo(v.getModelo());
                    b.setReferenciaVehiculo(v.getReferencia());
                    b.setMarcaVehiculo(v.getMarca());
                    b.setIDCliente(c.getId());
                    b.setNombreCliente(c.getNombre());
                    b.setEmailCliente(c.getEmail());  
                    Date date= new Date(); 
                    long time = date.getTime();
                    Timestamp ts = new Timestamp(time);
                    b.setFechaVenta(ts);
                    ventasFacade.create(b);
                    vehiculosFacade.remove(v);
                    url = "ConcesionarioServlet?action=listVehiculos";
                    break;  
                }               
                               
                default:
                    break;
            }
            response.sendRedirect(url);            
        } finally{
            out.close();
        }           
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
